package com.example.nortifytoatomlitelight;
/*
@Entity
data class User(
@PrimaryKey val uid: Int,
@ColumnInfo(name = "first_name") val firstName: String?,
@ColumnInfo(name = "last_name") val lastName: String?
        )

@Entity
public class NortifyToAtomLIteLightLog {

     @PrimaryKey
    public int uid;

    @ColumnInfo(name = "first_ame")
    public String firstName;

    @ColumnInfo(name = "last_name")
    public String lastName;


}
*/
